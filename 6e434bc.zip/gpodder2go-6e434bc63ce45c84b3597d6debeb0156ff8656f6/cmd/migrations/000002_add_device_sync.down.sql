DROP TABLE device_sync_groups;
DROP TABLE device_sync_group_devices;
