DROP TABLE device_sync_group_devices;
