ALTER TABLE devices
DROP COLUMN device_sync_group_id;
