DROP TABLE users;
DROP TABLE devices;
DROP TABLE subscriptions;
DROP TABLE episode_actions;
