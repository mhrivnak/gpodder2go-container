package main

import (
	"github.com/oxtyped/gpodder2go/cmd"
)

func main() {
	cmd.Execute()
}
