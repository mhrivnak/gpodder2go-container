CREATE UNIQUE INDEX unique_user_id_and_device_name_index ON devices(user_id, name);
